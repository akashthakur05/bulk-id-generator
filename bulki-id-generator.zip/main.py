from PIL import Image, ImageDraw, ImageFont
import openpyxl
import os
import qrcode

mylist=[]
def generator(list):
    print(list)
    image = Image.new('RGBA', (1000, 900), (255, 255, 255))
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype('arial.ttf', size=35)
    back=Image.open("res/des.jpg").convert("RGBA")
    sign=Image.open("res/sign.png").convert("RGBA")


    (x, y) = (50, 50)
    color = 'rgb(0, 0, 0)'
    draw.text((x,y),list[1],fill=color,font=font)
    #
    x,y=50,80
    font = ImageFont.truetype('arial.ttf', size=40)
    draw.text((x, y), list[0], fill=color, font=font)

    x,y=50,120
    font = ImageFont.truetype('arial.ttf', size=35)
    draw.text((x, y), list[2], fill=color, font=font)

    x, y = 50, 155
    font = ImageFont.truetype('arial.ttf', size=35)
    draw.text((x, y), list[3], fill=color, font=font)

    x, y = 50, 190
    font = ImageFont.truetype('arial.ttf', size=35)
    draw.text((x, y), list[4], fill=color, font=font)
    x, y = 50, 225
    font = ImageFont.truetype('arial.ttf', size=35)
    draw.text((x, y), str(list[5]), fill=color, font=font)

    x, y = 50, 255
    font = ImageFont.truetype('arial.ttf', size=35)
    draw.text((x, y), list[6], fill=color, font=font)

    image.save(list[0]+ '.png')
    til = Image.open(list[0] + '.png')

    img = qrcode.make(str(list))  # this info. is added in QR code, also add other things
    img.save(list[0] + '.bmp')
    im = Image.open(list[0] + '.bmp')  # 25x25
    til.paste(im, (40, 350))
    til.save(list[0] + '.png')
    os.unlink(list[0]+'.bmp')
    fore=Image.open(list[0]+".png")
    fore.paste(sign,(600,800))
    back.paste(fore,(575,75))
    back.save(list[0]+".png")



def main():
    temp=[]
    # os.system("Excel Id Generator By Thakur Akash")
    wb = openpyxl.load_workbook('res/details.xlsx')
    sheet=wb.sheetnames
    sheet=wb.active
    max_row,max_coloumn=sheet.max_row,sheet.max_column
    print(max_row,max_coloumn)
    for i in range(2,max_row+1):
        temp=[]
        for j in range(1,max_coloumn+1):
            cell_obj = sheet.cell(row=i, column=j)
            temp.append(cell_obj.value)
        temp[2]=temp[2].strftime("%d %b %Y ")
        mylist.append(temp)
    for value in mylist:
        generator(value)
    # print(mylist)



if __name__ == '__main__':
    main()

